public interface HealthPoint {
    int getHP();
    void setHP(int healthPoint);
    boolean isAlive();
}
