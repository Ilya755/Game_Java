import java.awt.*;

public interface Drawing {
    void draw(Graphics g);
}
