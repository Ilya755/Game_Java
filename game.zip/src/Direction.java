public class Direction {
    boolean up = false, down = false, right = false, left = false;

}
