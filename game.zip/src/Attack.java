public interface Attack {
    void toAttack(HealthPoint enemy);
}
