public class Main {
    static public void main(String[] args) {
        GameFrame gameFrame = new GameFrame(2000);
    }
}