public interface Moving {
    void move();
}
